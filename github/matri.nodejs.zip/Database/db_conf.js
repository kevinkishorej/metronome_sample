const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',
    host: '192.168.1.52',
    database: 'Matrimony',
    password: 'bsicodeseja0007',
    port: 5432,
});

pool.connect();

module.exports = pool;