const pool = require('./db_conf');

class database  {

//executeQuery......
static async executeQuery(query, array){
    return new Promise(async(resolve, reject) => {
        console.log(query,array,"executeQuery")
        pool.query(query, array,(err, result) => {
        try {
          
            if (err) {
                reject({query, array, err, error_msg: 'Database_send_an_error' });
              
            }else if (result){
                resolve (result.rows)

            }
        } catch (error) {
            return ('some_thing_went_worng')
        }
    });
    })
}



}


module.exports = database;