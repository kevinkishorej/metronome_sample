const router1 = require('./router');

module.exports = {
    ...router1
}