
const express = require('express'); //api package 
const app = express(); 
const http = require('http');
const server = http.createServer(app)
const io =  require('socket.io')(server);


module.exports = {

  //for validating the payload.....

  socket_:async(req,res,next)=>{

    io.on('connection', function(socket){
      socket.on('chat message', function(msg){
        io.emit('chat message', msg);
      });
      console.log(socket.id,'as joind');
      socket.on('event',(message)=>{
          console.log(message)
      })
      next();
    });
  },

}

