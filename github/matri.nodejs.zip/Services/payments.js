const express = require('express');
const { Router } = require('express');
const app = express(Router);
const database = require('../Database/db_query');
const jwt = require('jsonwebtoken')
const paypal = require('paypal-rest-sdk');
const  Client  = require('shopify-buy');
require('dotenv').config();
const fetch = require('node-fetch')
///paypall configure......
paypal.configure({
    'mode': 'sandbox', //sandbox or live
    'client_id': 'AVn1sQHk6eckyKkrMib7k4Kss6_oQT0IQxCVvVkQOsOVy92EYIwsIBErN8s-UNbl-rKniIz2IWF2iomj',
    'client_secret': 'EE1h0OuBUPkYJ8Pr5nGOiwLU4jsWywGiX_tXB_s5sO5F2-6P0lAZ6y3B08Vs4IWU5bF83z5yU9aOaKtD'
  });




////payment init .....from paypal

app.post('/paypall',async(req,res)=>{
    console.log("askndkjnsada")
    console.log(req);
    var create_payment_json = {
        "intent": "sale",
        "payer": {
            "payment_method": "paypal"
        },
        "redirect_urls": {
            "return_url": "http://192.168.1.104:3000/success",
            "cancel_url": "http://192.168.1.104:3000/cancel"
        },
        "transactions": [{
            "item_list": {
                "items": [{
                    "name": "item",
                    "sku": "item",
                    "price": "1.00",
                    "currency": "USD",
                    "quantity": 1
                }]
            },
            "amount": {
                "currency": "USD",
                "total": "1.00"
            },
            "description": "This is the payment description."
        }]
    };
     
     
    paypal.payment.create(create_payment_json, function (error, payment) {
        if (error) {
            throw error;
        } else {
            console.log("Create Payment Response");
            console.log(payment);
        }
    });
    
 
    
})

////success payment .....from paypal
app.get('/success', (req, res) => {

    console.log("asdsadasd")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
  
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
          "amount": {
              "currency": "USD",
              "total": "1.00"
          }
      }]
    };
  
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
      if (error) {
          console.log(error.response);
          throw error;
      } else {
          console.log(JSON.stringify(payment));
          res.send('Success');
      }
  });
  });




////cancel payment .....from paypal
  app.get('/cancel', (req, res) => res.send('Cancelled'));



  app.post("/image", function(req, res){
    var name = req.body.name;
    var img = req.body.image;
    var realFile = Buffer.from(img,"base64");
    fs.writeFile(name, realFile, function(err) {
        if(err)
           console.log(err);
     });
     res.send("OK");
   });

   const client = Client.buildClient({
    domain: 'https://d-store-test.myshopify.com/',
    storefrontAccessToken: 'efe4ba113306889b886ff7044de2c25c'
  });
  
  // Initializing a client to return translated content
  const clientWithTranslatedContent = Client.buildClient({
    domain: 'https://d-store-test.myshopify.com/',
    storefrontAccessToken: 'efe4ba113306889b886ff7044de2c25c',
    language: 'ja-JP'
  });

// Fetch a single product by ID
const productId = 'Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0Lzc4NTc5ODkzODQ=';
   app.get("/shope", function(req, res){
    
    client.product.fetch(productId).then((product) => {
        // Do something with the product
        console.log(product);
      });
   });


module.exports = app;