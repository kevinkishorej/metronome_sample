const express = require('express');
const { Router } = require('express');
const app = express(Router);
const database = require('../Database/db_query');
const jwt = require('jsonwebtoken')
const Jimp = require('jimp');
const fs = require('fs')
require('dotenv').config();

///add are update aboutme data...
app.post('/about_me',async(req,res)=>{
    console.log("askndkjnsada")
    console.log(req);
    const { id,user_id,full_name,marital_status,age,user_hight,user_weight,blood_group,religion_,eduction_,annual_icme,working_domain,state_ } = req.body;
    if(id == 'null'){
    console.log('dfdsf')  ;  
    var _id = null;
    }else{
     var  _id = id
    }
    var update_user_data = await database.executeQuery("select update_about_me_($1,$2,$3,$4,$5,$6,$7,$8,$9)",
    [_id,req.sessionPayload['id'],full_name,marital_status,age,user_hight,user_weight,blood_group,religion_]);
    console.log(update_user_data)
    res.status(200).json({
        "response": update_user_data,
        "status": 200,
    })
    
})





///get all details...
app.post('/get_about_me',async(req,res)=>{
    console.log("askndkjnsada")
 
    
    var get_user_data = await database.executeQuery("select get_user_about_me_details($1)",
    [req.sessionPayload['id']]);
    console.log(get_user_data)
    res.status(200).json({
        "response": get_user_data,
        "status": 200,
    })
    
})



//add family details...
app.post('/add_family',async(req,res)=>{
    console.log("askndkjnsada")
    console.log(req);
    var payload  = req.body;
    var get_ = await database.executeQuery("select add_user_family_details($1,$2,$3,$4,$5,$6)",
    [req.sessionPayload['id'],payload['fater_name'],payload['mother_name'],payload['number_of_bro'],payload['number_of_sis'],payload['delete_']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
    
})


//add partner preference details...

app.post('/add_partner_preference',async(req,res)=>{
    console.log("askndkjnsada")
    
    var payload  = req.body;
    console.log(payload);
    var get_ = await database.executeQuery("select add_user_partner_pre_details($1,$2,$3,$4,$5,$6,$7)",
    [req.sessionPayload['id'],payload['age_'],payload['marital_status'],payload['religion_'],payload['education_status'],payload['state_of_liveing'],payload['delete_']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
    
})

//add user location details...
app.post('/add_user_location',async(req,res)=>{
    console.log("askndkjnsada")
    var payload  = req.body;
    console.log(payload);
    var get_ = await database.executeQuery("select add_location_details($1,$2,$3,$4,$5,$6)",
    [req.sessionPayload['id'],payload['country_'],payload['city_'],payload['state__'],payload['citizenship_'],payload['pincode_']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
    
})


//add user professional_info details...
app.post('/add_professional_info',async(req,res)=>{
    console.log("askndkjnsada")
    var payload  = req.body;
  
    console.log(payload);
    var get_ = await database.executeQuery("select update_professional_info($1,$2,$3,$4,$5,$6,$7)",
    [req.sessionPayload['id'],payload['_education'],payload['college_'],payload['addiutional_degree'],payload['emploed_in'],payload['annual_income'],
    payload['delete_flag']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
    
})


//add user Basic  details...
app.post('/add_basic_info',async(req,res)=>{
    console.log("askndkjnsada")
    var payload  = req.body;
  
    console.log(payload);
    var get_ = await database.executeQuery("select update_user_basic_details($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)",
    [req.sessionPayload['id'],payload['profile_created_by'],payload['d_o_b'],payload['physical_statuc'],payload['body_type'],payload['skin_type'],
    payload['eating_habits'],payload['drinking_habit'],payload['smoking_habit'],payload['place_of_birth'],payload['behaviour_'],
    payload['personality_'], payload['facebook_profile_link']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
    
})



//add upload image  details...
 app.post('/add_image',async (req,res)=>{
    console.log("askndkjnsasasasasdsdsdsada")
    console.log(req.body)
    let payload = req.body; 
    var date1 = Date.now();
    var base64Data1 = payload['base64']
    var dir = './Public/images/profile/'

    if(!fs.existsSync(dir)){

        fs.mkdirSync(dir);
    }
    console.log("askndkjnsdsds22222222222222222222222dsada")
    var path = payload['user']+'|'+payload['ID']+'|'+date1+'.jpg'
    await require("fs").writeFile('./Public/images/profile/' + path, base64Data1, 'base64', function async(err) { 
        if(err){
            console.log(err)
        }else{
            res.status(200).json({
                "response": 'profile/'+payload['user']+'|'+payload['ID']+'|'+date1+'.jpg',
                "status": 200,
            }) 
        }
    })
 })

//add upload image  details...
app.post('/profile_imag_update',async (req,res)=>{
    console.log("askndkjnsdsdsdsada")
    console.log(req.body)
    var payload  = req.body;
    if(payload['cover_photo']=='null'){
        payload['cover_photo'] = null
    }
    if(payload['user_img']=='null'){
        payload['user_img'] = null
    }
    console.log(payload);
    var get_ = await database.executeQuery("select update_profile_img($1,$2,$3)",
    [req.sessionPayload['id'],payload['user_img'],payload['cover_photo']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
 })

module.exports = app;
