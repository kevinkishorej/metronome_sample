const schema = require('../index');
const jwt = require('jsonwebtoken')
require('dotenv').config();
module.exports = {

    //for validating the payload.....

    Schema_validator:async(req,res,next)=>{

        var path = req.url;
        var value =  await schema[path];
        value =  await value.validate(req.body);
        if(value.error){
           res.send({ERROR:value.error.message})
        }else{
            next()
        }
    },

    JWT_validator:async(req,res,next)=>{
        var token = req.headers['authorization'];
        console.log(token,"atokensdasd")
        var value =  await jwt.verify(token,process.env.secret_ket ,(err, decoded)=> {
            console.log(decoded)
            if(err){res.json('Session_time_out JWT is expired') }
            else{
                req.sessionPayload = decoded
                console.log(req.sessionPayload ,"sadsadsad")
                next();
            }
        
        })
    }



}