const joi = require('@hapi/joi');

const schema ={
    "/about_me":joi.object({
        'id':joi.string().max(100).required(),
        'user_id' :joi.string().max(1000).required(),
        'full_name' :joi.string().max(100).required(),
        'marital_status'  :joi.string().max(100),
        'age':joi.number().max(100),
        'user_hight' :joi.string().max(100),
        'user_weight' :joi.string().max(100),
        'blood_group' :joi.any(),
        'religion_':joi.string().max(100),

    }),


    "/get_about_me":joi.object({
        'user_id' :joi.string().max(1000).required(),
    }),


    "/add_family":joi.object({
        'user_id' :joi.string().max(1000).required(),
        'fater_name' :joi.string().max(1000).required(),
        'mother_name' :joi.string().max(1000).required(),
        'number_of_bro' :joi.number().max(1000).required(),
        'number_of_sis' :joi.number().max(1000).required(),
        'delete_' :joi.boolean().required(),
    }),


    "/add_partner_preference":joi.object({
        'user_id' :joi.string().max(1000).required(),
        'age_' :joi.string().max(100).required(),
        'marital_status' :joi.string().max(100).required(),
        'religion_' :joi.string().max(100).required(),
        'education_status' :joi.string().max(100).required(),
        'state_of_liveing' :joi.string().max(100).required(),
        'delete_' :joi.boolean().required(),
    }),

    "/add_user_location":joi.object({
        'user_id' :joi.string().max(1000).required(),
        'country_' :joi.string().max(100).required(),
        'city_' :joi.string().max(100).required(),
        'state__' :joi.string().max(100).required(),
        'citizenship_' :joi.string().max(100).required(),
        'pincode_' :joi.string().max(100).required(),
       
    }),

    "/add_professional_info":joi.object({
        'user_id' :joi.string().max(1000).required(),
        '_education' :joi.string().max(100),
        'college_' :joi.string().max(100),
        'addiutional_degree' :joi.string().max(100),
        'emploed_in' :joi.string().max(100),
        'annual_income' :joi.string().max(100),
        'delete_flag' :joi.boolean().required(),
       
    }),

    "/add_image":joi.object({
        'ID':joi.any().required(),
        'user':joi.string().max(1000).required(),
        'base64' :joi.any().required(),
        
       
    }),
    
    "/profile_imag_update":joi.object({
        'user_id':joi.any().required(),
        'user_img':joi.any().required(),
        'cover_photo':joi.any(),
    }),


    "/add_basic_info":joi.object({
        'user_id':joi.any().required(),
        'profile_created_by' :joi.string().max(100),
        'd_o_b' :joi.string().max(100),
        'physical_statuc' :joi.string().max(100),
        'body_type' :joi.string().max(100),
        'skin_type' :joi.string().max(100),
        'eating_habits' :joi.string().max(100),
        'drinking_habit' :joi.string().max(100),
        'smoking_habit' :joi.string().max(100),
        'place_of_birth' :joi.string().max(100),
        'behaviour_' :joi.string().max(100),
        'personality_' :joi.string().max(100),
        'facebook_profile_link' :joi.string().max(100),
    }),


    "/add_chat_contact":joi.object({
        'user_id':joi.any().required(),
        'contact_id' :joi.number().max(100).required(),
        'person_name' :joi.string().max(100).required(),
        'delete_flag' :joi.boolean().required(),
   
    }),
    
    "/get_contact":joi.object({
        'user_id':joi.any().required(),

    }),

   
    "/add_message":joi.object({
        'user_id':joi.any().required(),
        'reciver_id' :joi.number().max(100).required(),
        'message_' :joi.string().max(100).required(),
        'img_message' :joi.string(),
        'seen_' :joi.boolean().required(),
        'delete_flag' :joi.boolean().required(),
   
    }),


    "/get_user_message":joi.object({
        'user_id':joi.any().required(),
        'reciver_id' :joi.number().max(100).required(),
        'contact_list_id' :joi.number(),   
    }),
}
module.exports = schema;