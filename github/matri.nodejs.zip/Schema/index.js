const login = require('./login_schema');
const about_me = require('./add_user_details')




//all schema need to import here to validate the schema.....
module.exports = {
    ...login, 
    ...about_me
}