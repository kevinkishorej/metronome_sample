package com.example.trade

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
