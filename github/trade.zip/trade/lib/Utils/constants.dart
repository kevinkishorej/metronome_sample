import 'dart:ui';

import 'package:flutter/material.dart';

class Constants {
  static const List<Color> colors = [
    Colors.teal,
    Colors.black87,
    Colors.blue,
    Colors.purple,
    Colors.indigo,
    Colors.green,
    Colors.red,
    Colors.amber,
    Colors.brown,
    Colors.deepOrange,
    Colors.blueAccent,
  ];
}
