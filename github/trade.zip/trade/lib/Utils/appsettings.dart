import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:trade/Utils/constants.dart';

class Appsettings extends ChangeNotifier {
  //
  Color _appcolor = Colors.teal;
  Color get appcolor => _appcolor;

  void updatecolor(int index) {
    _appcolor = Constants.colors[index];
    notifyListeners();
  }
}
