import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Utils {
  //
  static Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  static const THEME_INDEX_KEY = 'theme_index';
  static const LOGGED_IN = 'logged_in';
  static getTF(TextEditingController controller) {
    return TextField(
      controller: controller,
    );
  }

  static savethemeindex(int themeindex) async {
    final SharedPreferences prefs = await _prefs;
    prefs.setInt(THEME_INDEX_KEY, themeindex);
  }

  static getthemeindex() async {
    final SharedPreferences prefs = await _prefs;
    int themeindex = prefs.getInt(THEME_INDEX_KEY);
    if (null == themeindex) {
      themeindex = 0;
    }
    return themeindex;
  }

  static savedloggedin(bool loggedin) async {
    final SharedPreferences prefs = await _prefs;
    prefs.setBool(LOGGED_IN, loggedin);
  }

  static isloggedin() async {
    final SharedPreferences prefs = await _prefs;
    bool isloggedin = prefs.getBool(LOGGED_IN);
    return null != isloggedin && isloggedin;
  }
}
