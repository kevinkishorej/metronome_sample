// import 'dart:js';

import 'dart:js';

import 'package:trade/Screen/family_details.dart';
import 'package:trade/Screen/home_screen.dart';
import 'package:trade/Screen/login_screen.dart';
import 'package:trade/Screen/otp_loginpage.dart';
import 'package:trade/Screen/partner_pref.dart';
import 'package:trade/Screen/profile.dart';
import 'package:trade/Screen/profile/main_profile.dart';
import 'package:trade/Screen/signup_screen.dart';

class Routes {
  //
  static routes() {
    return {
      OtpLoginScreen.ROUTE_ID: (context) => OtpLoginScreen(),
      // Loginscreen.ROUTE_ID: (context) => main_profile(),
      Loginscreen.ROUTE_ID: (context) =>  HomeScreen(),
      SignupScreen.ROUTE_ID: (context) => SignupScreen(),
      ProfilePage.ROUTE_ID: (context) => ProfilePage(),
      FamilyDetails.ROUTE_ID: (context) => FamilyDetails(),
      PartnerPref.ROUTE_ID: (context) => PartnerPref(),

      HomeScreen.ROUTE_ID: (context) => HomeScreen(),
      // Settingsscreen.ROUTE_ID: (context) => Settingsscreen(),
    };
  }

  static otploginscreen() {
    return OtpLoginScreen.ROUTE_ID;
  }

  static familydetails() {
    return FamilyDetails.ROUTE_ID;
  }

  static partnerpref() {
    return PartnerPref.ROUTE_ID;
  }
  
  static initialroute() {
    return Loginscreen.ROUTE_ID;

    // return OtpLoginScreen.ROUTE_ID;
  }

  static homeroute() {
    return HomeScreen.ROUTE_ID;
  }

  static profileroute() {
    return ProfilePage.ROUTE_ID;
  }

  static signuproute() {
    return SignupScreen.ROUTE_ID;
  }
}
