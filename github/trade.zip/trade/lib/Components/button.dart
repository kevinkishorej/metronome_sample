import 'package:flutter/material.dart';

class Btn extends StatelessWidget {
  Btn({this.onpress, this.text, this.color});
  final Function onpress;
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: color,
      margin: EdgeInsets.all(10),
      child: ElevatedButton(
        onPressed: onpress,
        child: Text(
          text,
          style: TextStyle(color: Colors.white),
        ),
        style: ElevatedButton.styleFrom(
          primary: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(3.0),
          ),
        ),
      ),
    );
  }
}
