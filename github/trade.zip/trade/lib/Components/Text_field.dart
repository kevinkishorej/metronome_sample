import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_pw_validator/flutter_pw_validator.dart';

class TF extends StatelessWidget {
//

  TF({
    this.controller,
    this.hinttext,
    this.helptext,
    this.prefixicon,
    this.suffixicon,
    this.ispassword,
    this.enabled,
    this.readonly,
    this.bordercolor,
    // this.validcheck,
    this.onChanged,
    this.validator,
    this.onFieldSubmitted,
    this.keyboardtype,
    this.inputformaters,
  });
  final TextEditingController controller;
  final String hinttext;
  final String helptext;
  final IconData prefixicon;
  final Function onChanged;
  final Function validator;
  final Function onFieldSubmitted;
  final dynamic keyboardtype;
  final dynamic inputformaters;
  final IconData suffixicon;
  final bool ispassword;
  final bool enabled;
  final bool readonly;
  final Color bordercolor;
  // final String validcheck;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2.0),
            child: TextFormField(
              onChanged: onChanged,
              validator: validator,
              onFieldSubmitted: onFieldSubmitted,
              // keyboardType: keyboardtype,
              // inputFormatters: [inputformaters],
              controller: controller,
              readOnly: null == readonly ? false : true,
              obscureText: null == ispassword ? false : true,
              decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.greenAccent,
                    width: 1.0,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.greenAccent,
                    width: 1.0,
                  ),
                ),
                border: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: null == bordercolor ? Colors.teal : bordercolor,
                    width: 1.0,
                  ),
                ),
                hintText: null == hinttext ? '' : hinttext,
                helperText: null == helptext ? '' : helptext,
                prefixIcon: null == prefixicon ? null : Icon(prefixicon),
                suffix: null == suffixicon ? null : Icon(suffixicon),
                enabled: null == enabled ? true : false,
              ),
            ),
          ),
          new SizedBox(
            height: 5,
          ),
          // new FlutterPwValidator(
          //   controller: controller,
          //   minLength: 8,
          //   uppercaseCharCount: 2,
          //   numericCharCount: 3,
          //   specialCharCount: 1,
          //   width: 400,
          //   height: 150,
          //   onSuccess: () {
          //     print("Matched");
          //     Scaffold.of(context).showSnackBar(
          //         new SnackBar(content: new Text("Password is matched")));
          //   },
          // ),
        ],
      ),
    );
  }
}
