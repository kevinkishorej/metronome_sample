import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:trade/Utils/appsettings.dart';
import 'package:trade/Utils/routes.dart';
import 'package:trade/Utils/utils.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  String route = Routes.initialroute();
  bool isloggedin = await Utils.isloggedin();
  if (isloggedin) {
    route = Routes.homeroute();
  }
  runApp(MyApp(
    route: route,
  ));
}

class MyApp extends StatelessWidget {
  MyApp({this.route});
  final String route;
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => Appsettings(),
        ),
      ],
      child: MaterialApp(
        title: 'Flutter Demo Application',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.green,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        // home: Loginscreen(),
        routes: Routes.routes(),
        initialRoute: route,
      ),
    );
  }
}
