import 'package:flutter/material.dart';
import 'package:trade/Screen/otp.dart';
import 'package:trade/Screen/signup_screen.dart';
import 'package:trade/Utils/appsettings.dart';
// import 'package:trade/utils/utils.dart';
import 'package:provider/provider.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:trade/Components/button.dart';

class OtpLoginScreen extends StatefulWidget {
  static const ROUTE_ID = "Otplogin_screen";
  @override
  _OtpLoginScreenState createState() => _OtpLoginScreenState();      
}

class _OtpLoginScreenState extends State<OtpLoginScreen> {
  TextEditingController _mobilecontroller;
  GlobalKey<FormState> key = GlobalKey<FormState>();
  @override
  void initState() {
    super.initState();
    _mobilecontroller = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(10),
        child: Form(
          key: key,
          child: Column(
            children: [
              // TextField(
              //   controller: _emailcontroller,
              // ),
              // Utils.getTF(_emailcontroller),
              // Utils.getTF(_passwordcontroller),
              // TextField(
              //   controller: _emailcontroller,
              // ),
              TF(
                controller: _mobilecontroller,

                // onChanged: (value) => validate(),
                hinttext: 'Mobile No',
                // helptext: 'E-mail',
                prefixicon: Icons.email,
                // validator: (value) {
                //   if (value.isEmpty) {
                //     return "required";
                //   } else if (value.length < 6) {
                //     return "Should be at least 6 characters";
                //   } else if (value.length > 15) {
                //     return "should not be more than 15 characters";
                //   } else {
                //     return null;
                //   }
                // },
              ),

              // TF(
              //   controller: _passwordcontroller,
              //   hinttext: 'Password',
              //   onChanged: (value) => validate(),
              //   // helptext: 'Password',
              //   ispassword: true,
              //   validator: (value) {
              //     if (value.isEmpty) {
              //       return "required";
              //     } else if (value.length < 6) {
              //       return "Should be at least 6 characters";
              //     } else if (value.length > 15) {
              //       return "should not be more than 15 characters";
              //     } else {
              //       return null;
              //     }
              //   },
              //   prefixicon: Icons.lock_open,
              // ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        // validate();
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) {
                          return OtpScreen(_mobilecontroller.text);
                          // return OtpScreen();
                        }));
                        // Utils.savedloggedin(true);
                      },
                      text: "Login",
                      color: context.watch<Appsettings>().appcolor,
                    ),
                  ),
                ],
              ),
              // Row(
              //   children: [
              //     Expanded(
              //       child: Btn(
              //         onpress: () {
              //           // validate();
              //           // Navigator.push(context,
              //           //     MaterialPageRoute(builder: (context) {
              //           //   return SignupScreen();
              //           // }));
              //           // Utils.savedloggedin(true);
              //         },
              //         text: "signup",
              //         // color: context.watch<Appsettings>().appcolor,
              //         color: Colors.blueAccent,
              //       ),
              //     ),
              //   ],
              // ),
              // Linkbtn(
              //   text: "Forgot password ?",
              //   onpress: () {},
              //   color: context.watch<Appsettings>().appcolor,
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
