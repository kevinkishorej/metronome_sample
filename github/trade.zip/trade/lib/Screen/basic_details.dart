import 'package:flutter/material.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:trade/Components/button.dart';
import 'dart:convert';
import 'package:trade/Screen/services/request_confic.dart';

class BasicDetails extends StatefulWidget {
  static const ROUTE_ID = 'basic_details';
  @override
  _BasicDetailsState createState() => _BasicDetailsState();
}

class _BasicDetailsState extends State<BasicDetails> {
  TextEditingController _pcreatedby;
  TextEditingController _physicalstatus;
  TextEditingController _bodytype;
  TextEditingController _eatinghabits;
  TextEditingController _drinkinghabits;
  TextEditingController _smokinghabits;
  TextEditingController _attitude;
  TextEditingController _familybackground;
  TextEditingController _dateofbirth;
  TextEditingController _placeofbirth;
  TextEditingController _skintype;
  TextEditingController _personality;
  TextEditingController _facebooklink;
  Map<String, dynamic> map = {};
  NetworkHandler networkHandler = NetworkHandler();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _pcreatedby = TextEditingController();
    _physicalstatus = TextEditingController();
    _bodytype = TextEditingController();
    _eatinghabits = TextEditingController();
    _drinkinghabits = TextEditingController();
    _smokinghabits = TextEditingController();
    _attitude = TextEditingController();
    _familybackground = TextEditingController();
    _dateofbirth = TextEditingController();
    _placeofbirth = TextEditingController();
    _skintype = TextEditingController();
    _personality = TextEditingController();
    _facebooklink = TextEditingController();
  }

  GlobalKey<FormState> key = GlobalKey<FormState>();
  String validatepass(value) {
    if (value.isEmpty) {
      return "required";
    } else if (value.length < 6) {
      return "Should be at least 6 characters";
    } else if (value.length > 15) {
      return "should not be more than 15 characters";
    } else {
      return null;
    }
  }

  validate() {
    key.currentState.validate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Basic_details Page'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Form(
          child: Column(
            children: [
              TF(
                hinttext: 'Profile Created By',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _pcreatedby,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Profile Created By',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _pcreatedby,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Physical status',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _physicalstatus,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Body Type',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _bodytype,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Eating Habits',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _eatinghabits,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Drinking habits',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _drinkinghabits,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Smoking habits',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _smokinghabits,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Attitude',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _attitude,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Family Background',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _familybackground,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Date Of Birth',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _dateofbirth,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Place of Birth',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _placeofbirth,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Skin Type',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _skintype,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Personality',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _personality,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Facebook Profile Link',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _facebooklink,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        // if (key.currentState.validate() == false) {
                        //   validate();
                        // } else {
                        map = {
                          // 'id': 'null',
                          'user_id': 'null',
                          'profile_created_by': _pcreatedby.text,
                          'd_o_b': _dateofbirth.text,
                          'physical_statuc': _physicalstatus.text,
                          'body_type': _bodytype.text,
                          'skin_type': _skintype.text,
                          'eating_habits': _eatinghabits.text,
                          'drinking_habit': _drinkinghabits.text,
                          'smoking_habit': _smokinghabits.text,
                          'place_of_birth': _placeofbirth.text,
                          'behaviour_': _attitude.text,
                           'personality_': _personality.text,
                          'facebook_profile_link': _facebooklink.text,
                          // '':_professionalin.text,
                          // '':_professionalin.text,
                          
                        };
                        basicdetails(map);
                        print('tttttttttttttttttttttt');
                        print(map);
                        // }
                      },
                      text: "Submit",
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void basicdetails(map) async {
    print(map);
    print('userprofile map printinggggg');
    // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    // header.customHeaders['Authorization'] =
    //     sharedPreferences.getString('token');
    // print(header.customHeaders);
    // http.Response response = await http.post(
    //     Uri.parse('http://localhost:3000/about_me'),
    //     headers: header.customHeaders,
    //     body: jsonEncode(map));
    // print('sending data to the server');
    // print(response.body.toString());
    var response = await networkHandler.post('/add_basic_info', map);
    print(response.toString());

    print(response["status"]);
    var result = response["status"];

    if (result == 200) {
      showAlertDialog(context);
    } else if (result == 400) {
      setState(() {
        final snackBar = SnackBar(content: Text('Ooops! something went wrong'));
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
      });
    }
  }
}

// Alert Dialog for sign up

showAlertDialog(BuildContext context) {
  // Create button
  Widget okButton = ElevatedButton(
    child: Text("OK"),
    onPressed: () {
      Navigator.of(context).pop();
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return BasicDetails();
      }));
    },
  );

  // Create AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("saved successfully"),
    content: Text("congratz your data saved"),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
