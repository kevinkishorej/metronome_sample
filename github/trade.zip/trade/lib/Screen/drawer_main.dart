import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trade/Screen/basic_details.dart';
import 'package:trade/Screen/family_details.dart';
import 'package:trade/Screen/login_screen.dart';
import 'package:trade/Screen/partner_pref.dart';
import 'package:trade/Screen/professional_details.dart';
import 'package:trade/Screen/profile.dart';
import 'package:image_picker/image_picker.dart';
import 'package:trade/Screen/profile/main_profile.dart';

class MainDrawer extends StatelessWidget {
  final picker = ImagePicker();

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(vertical: 20, horizontal: 5),
            color: Theme.of(context).primaryColor,
            child: Center(
              child: Stack(
                children: [
                  // Container(
                  //   width: 100,
                  //   height: 100,
                  //   margin: EdgeInsets.only(top: 30, bottom: 10),
                  //   decoration: BoxDecoration(
                  //     shape: BoxShape.circle,

                  //     image: DecorationImage(

                  //         image: NetworkImage(
                  //             'https://images.unsplash.com/photo-1556103255-4443dbae8e5a?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=338&q=80'),
                  //         fit: BoxFit.fill),
                  //   ),
                  // ),
                  CircleAvatar(
                    radius: 70.0,
                    backgroundImage: NetworkImage(
                        'https://images.unsplash.com/photo-1556103255-4443dbae8e5a?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=338&q=80'),
                  ),
                  //   Positioned(
                  //     bottom: 20.0,
                  //     right: 20.0,
                  //     child: InkWell(
                  //        onTap: (){
                  // // await checkuser();
                  //        },
                  //       child: Icon(Icons.camera_alt,
                  //       size: 28,
                  //       color:Theme.of(context).primaryColor,),
                  //     )
                  //     ),
                ],
              ),
            ),
          ),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 2),
            color: Theme.of(context).primaryColor,
            child: Center(
              child: Column(
                children: [
                  Text(
                    'Text Name Here',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  Text(
                    'Email Here',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
          SingleChildScrollView(
              child: Column(
            children: [
              ListTile(
                leading: Icon(Icons.person),
                title: Text(
                  'Profile Edit',
                  style: TextStyle(fontSize: 15),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return ProfilePage();
                  }));
                },
              ),
              ListTile(
                leading: Icon(Icons.face),
                title: Text(
                  'Family Details',
                  style: TextStyle(fontSize: 15),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return FamilyDetails();
                  }));
                },
              ),
              ListTile(
                leading: Icon(Icons.person),
                title: Text(
                  'Partner Preferences',
                  style: TextStyle(fontSize: 15),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return PartnerPref();
                  }));
                },
              ),
              ListTile(
                leading: Icon(Icons.face),
                title: Text(
                  'Your Profile',
                  style: TextStyle(fontSize: 15),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return main_profile();
                  }));
                },
              ),
              ListTile(
                leading: Icon(Icons.face),
                title: Text(
                  'Professional Details',
                  style: TextStyle(fontSize: 15),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return ProfessionalDetails();
                  }));
                },
              ),
              ListTile(
                leading: Icon(Icons.face),
                title: Text(
                  'Basic Details',
                  style: TextStyle(fontSize: 15),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return BasicDetails();
                  }));
                },
              ),
              // ListTile(
              //   leading: Icon(Icons.settings),
              //   title: Text(
              //     'Settings',
              //     style: TextStyle(fontSize: 15),
              //   ),
              //   onTap: () {},
              // ),
              ListTile(
                leading: Icon(Icons.arrow_back),
                title: Text(
                  'Logout',
                  style: TextStyle(fontSize: 15),
                ),
                onTap: () async{
                  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
                  sharedPreferences.remove('token');
                    Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return Loginscreen();
                  }));
                },
              ),
            ],
          ))
        ],
      ),
    );
  }

  static Map<String, String> customHeaders = {
    'content-type': 'application/json',
    "Access-Control-Allow-Origin": "*", // Required for CORS support to work
    "Access-Control-Allow-Credentials":
        "true", // Required for cookies, authorization headers with HTTPS
    "Access-Control-Allow-Headers":
        "Origin,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    'Authorization': '',
  };

  void _verifyuser(map) async {
    print(map);
    print('gjdfkhgdjkfhgdfg');
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    customHeaders['Authorization'] = sharedPreferences.getString('token');
    http.Response response = await http.post(
        Uri.parse('http://localhost:3000/user_login'),
        headers: customHeaders);

    print('request sended to the server');
    print(response.body.toString());
  }
}
