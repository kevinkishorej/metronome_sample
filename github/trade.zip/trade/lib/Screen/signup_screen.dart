import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:trade/Components/button.dart';
import 'package:trade/Screen/login_screen.dart';
// import 'package:trade/Comunication/http/http.dart';
import 'package:trade/Utils/appsettings.dart';
// import 'package:trade/Utils/utils.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SignupScreen extends StatefulWidget {
  static const ROUTE_ID = "signup_scren";
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

void _createuser() async {
  http.Response response =
      await http.get(Uri.parse('http://localhost:3000/select'));
  print(response.body);
  // return null;
}

class _SignupScreenState extends State<SignupScreen> {
  TextEditingController _emailcontroller;
  TextEditingController _passwordcontroller;
  TextEditingController _usernamecontroller;
  TextEditingController _mobilecontroller;
  // TextEditingController _confirmpasswordcontroller;
  Map<String, dynamic> map = {};
  @override
  void initState() {
    super.initState();
    _emailcontroller = TextEditingController();
    _passwordcontroller = TextEditingController();
    _usernamecontroller = TextEditingController();
    _mobilecontroller = TextEditingController();
    // _confirmpasswordcontroller = TextEditingController();
  }

  GlobalKey<FormState> key = GlobalKey<FormState>();
  String validatepass(value) {
    if (value.isEmpty) {
      return "required";
    } else if (value.length < 6) {
      return "Should be at least 6 characters";
    } else if (value.length > 15) {
      return "should not be more than 15 characters";
    } else {
      return null;
    }
  }

  validate() {
    key.currentState.validate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: context.watch<Appsettings>().appcolor,
        title: Text("Signup"),
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        child: Form(
          key: key,
          child: Column(
            children: [
              // TextField(
              //   controller: _emailcontroller,
              // ),
              // Utils.getTF(_emailcontroller),
              // Utils.getTF(_passwordcontroller),
              // TextField(
              //   controller: _emailcontroller,
              // ),
              TF(
                hinttext: 'User Name',
                onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _usernamecontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  } else if (value.length < 6) {
                    return "Should be at least 6 characters";
                  }
                },
              ),
              TF(
                controller: _emailcontroller,
                hinttext: 'E-mail',
                onChanged: (value) => validate(),

                // helptext: 'E-mail',
                prefixicon: Icons.email,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // } else if (value.length > 15) {
                  //   return "should not be more than 15 characters";
                  // }
                  // else {
                  //   return null;
                  // }
                },
              ),
              TF(
                controller: _passwordcontroller,
                hinttext: 'Password',
                onChanged: (value) => validate(),
                // helptext: 'Password',
                // ispassword: true,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  } else if (value.length < 6) {
                    return "Should be at least 6 characters";
                  } else if (value.length > 15) {
                    return "should not be more than 15 characters";
                  } else {
                    return null;
                  }
                },
                prefixicon: Icons.lock,
              ),

              TF(
                hinttext: 'Mobile Number',
                onChanged: (value) => validate(),
                prefixicon: Icons.mobile_friendly,
                controller: _mobilecontroller,
                // inputformaters: FilteringTextInputFormatter.digitsOnly,
                // keyboardtype: TextInputType.number,
                validator: (value) {
                  if (value.isEmpty) {
                    return 'required';
                  }
                },
              ),

              // TF(
              //   controller: _confirmpasswordcontroller,
              //   hinttext: 'Confirm Password',
              //   onChanged: (value) => validate(),
              //   // helptext: 'Password',
              //   // ispassword: true,
              //   validator: (value) {
              //     if (value.isEmpty) {
              //       return "required";
              //     } else if (value.length < 6) {
              //       return "Should be at least 6 characters";
              //     } else if (value.length > 15) {
              //       return "should not be more than 15 characters";
              //     } else if (_confirmpasswordcontroller.text !=
              //         _passwordcontroller.text) {
              //       return "Password Must match";
              //     } else {
              //       return null;
              //     }
              //   },
              //   prefixicon: Icons.lock_open,
              // ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        // _createuser();
                        if (key.currentState.validate() == false) {
                          validate();
                        } else {
                          map = {
                            'user_name': _usernamecontroller.text,
                            'email': _emailcontroller.text,
                            'mobile': _mobilecontroller.text,
                            'password': _passwordcontroller.text,
                            // 'confirm_password': _confirmpasswordcontroller.text,
                          };
                          _createuserr(map);
                          print('tttttttttttttttttttttt');
                          print(map);
                        }

                        // Navigator.push(context,
                        //     MaterialPageRoute(builder: (context) {
                        //   return Homescreen();
                        // }));
                        // Utils.savedloggedin(true);
                      },
                      text: "Submit",
                      // color: context.watch<Appsettings>().appcolor,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
              // Row(
              //   children: [
              //     Expanded(
              //       child: Btn(
              //         onpress: () {
              //           // validate();
              //           Navigator.push(context,
              //               MaterialPageRoute(builder: (context) {
              //             return SignupScreen();
              //           }));
              //           // Utils.savedloggedin(true);
              //         },
              //         text: "signup",
              //         // color: context.watch<Appsettings>().appcolor,
              //         color: Colors.blueAccent,
              //       ),
              //     ),
              //   ],
              // ),
              // Linkbtn(
              //   text: "Forgot password ?",
              //   onpress: () {},
              //   color: context.watch<Appsettings>().appcolor,
              // ),
            ],
          ),
        ),
      ),
    );
  }

  // sign up function

  void _createuserr(map) async {
    print(map);
    print("ldlakldakld");
    http.Response response =
        await http.post(Uri.parse('http://localhost:3000/insert'), body: map);

    print('OOOOOOOOOOOOOOOOOOOOO');
    print(response.body.toString());
    print(jsonDecode(response.body.toString())["status"]);
    var result = jsonDecode(response.body.toString())["status"];

    if (result == 200) {
      showAlertDialog(context);
    } else if (result == 400) {
      setState(() {
        final snackBar = SnackBar(content: Text('Ooops! something went wrong'));
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
      });
    }
  }
}

// Alert Dialog for sign up

showAlertDialog(BuildContext context) {
  // Create button
  Widget okButton = ElevatedButton(
    child: Text("OK"),
    onPressed: () {
      Navigator.of(context).pop();
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return Loginscreen();
      }));
    },
  );

  // Create AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("signup successfully"),
    content: Text("Now you will be redirected to next page"),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
