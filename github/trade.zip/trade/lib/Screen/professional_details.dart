import 'package:flutter/material.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:trade/Components/button.dart';
import 'package:trade/Screen/services/request_confic.dart';

class ProfessionalDetails extends StatefulWidget {
  static const ROUTE_ID = 'Professional_details';
  @override
  _ProfessionalDetailsState createState() => _ProfessionalDetailsState();
}

class _ProfessionalDetailsState extends State<ProfessionalDetails> {
  TextEditingController _highereducation;
  TextEditingController _collegename;
  TextEditingController _aditionaldegree;
  TextEditingController _employedin;
  TextEditingController _anualincome;
  TextEditingController _professionalin;
  Map<String, dynamic> map = {};
  NetworkHandler networkHandler = NetworkHandler();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _highereducation = TextEditingController();
    _collegename = TextEditingController();
    _aditionaldegree = TextEditingController();
    _employedin = TextEditingController();
    _anualincome = TextEditingController();
    _professionalin = TextEditingController();
  }

  GlobalKey<FormState> key = GlobalKey<FormState>();
  String validatepass(value) {
    if (value.isEmpty) {
      return "required";
    } else if (value.length < 6) {
      return "Should be at least 6 characters";
    } else if (value.length > 15) {
      return "should not be more than 15 characters";
    } else {
      return null;
    }
  }

  validate() {
    key.currentState.validate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Professional Details Page'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Form(
          child: Column(
            children: [
              TF(
                hinttext: 'Higher Education',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _highereducation,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'College Name',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _collegename,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Additional Degree',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _aditionaldegree,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Employed In',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _employedin,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Anual Income',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _anualincome,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Professional in',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _professionalin,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        // if (key.currentState.validate() == false) {
                        //   validate();
                        // } else {
                        map = {
                          // 'id': 'null',
                          'user_id': 'null',
                          '_education': _highereducation.text,
                          'college_': _collegename.text,
                          'addiutional_degree': _aditionaldegree.text,
                          'emploed_in': _employedin.text,
                          'annual_income': _anualincome.text,
                          // '':_professionalin.text,

                          'delete_flag': false
                        };
                        professionaldetails(map);
                        print('tttttttttttttttttttttt');
                        print(map);
                        // }
                      },
                      text: "Submit",
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void professionaldetails(map) async {
    print(map);
    print('userprofile map printinggggg');
    // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    // header.customHeaders['Authorization'] =
    //     sharedPreferences.getString('token');
    // print(header.customHeaders);
    // http.Response response = await http.post(
    //     Uri.parse('http://localhost:3000/about_me'),
    //     headers: header.customHeaders,
    //     body: jsonEncode(map));
    // print('sending data to the server');
    // print(response.body.toString());
    var response = await networkHandler.post('/add_professional_info', map);
    print(response.toString());

    print(response["status"]);
    var result = response["status"];

    if (result == 200) {
      showAlertDialog(context);
    } else if (result == 400) {
      setState(() {
        final snackBar = SnackBar(content: Text('Ooops! something went wrong'));
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
      });
    }
  }
}

// Alert Dialog for sign up

showAlertDialog(BuildContext context) {
  // Create button
  Widget okButton = ElevatedButton(
    child: Text("OK"),
    onPressed: () {
      Navigator.of(context).pop();
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return ProfessionalDetails();
      }));
    },
  );

  // Create AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("saved successfully"),
    content: Text("congratz your data saved"),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
