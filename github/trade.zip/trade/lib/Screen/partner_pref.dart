import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:trade/Components/button.dart';
import 'package:http/http.dart' as http;
import 'package:trade/Screen/services/header.dart';
import 'package:trade/Screen/services/request_confic.dart';

class PartnerPref extends StatefulWidget {
  static const ROUTE_ID = 'Partner_pref';

  @override
  _PartnerPrefState createState() => _PartnerPrefState();
}

class _PartnerPrefState extends State<PartnerPref> {
  bool flag = false;
  TextEditingController _age;
  TextEditingController _maritalstatus;
  TextEditingController _religion;
  TextEditingController _education;
  TextEditingController _state;
  NetworkHandler networkHandler = NetworkHandler();
  Map<String, dynamic> map = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _age = TextEditingController();
    _maritalstatus = TextEditingController();
    _religion = TextEditingController();
    _education = TextEditingController();
    _state = TextEditingController();
    _age.text = 'sadasd';
    get_user_details();
  }
  void get_user_details() async {
    var response = await networkHandler.post('/get_about_me', map2);
    response =
        json.decode(response['response'][0]['get_user_about_me_details']);
    print(response);
    setState(() {
      mapResponse = response['data'];
      print('sssssssssssssssssssssssssssssssss');
      print(mapResponse);
      _age.text =  mapResponse['age_'].toString();
     _maritalstatus.text = mapResponse['pp_marital_status'];
      _religion.text = mapResponse['pp_religion_'];
      _education.text = mapResponse['education_status'];
     _state.text = mapResponse['state_of_liveing'];
      print('sssssssssssssssssssssssssssssssss');
    });
  }
  Map<String, String> map2 = {'user_id': 'null'};
  Map<String, dynamic> mapResponse;
  GlobalKey<FormState> key = GlobalKey<FormState>();
  String validatepass(value) {
    if (value.isEmpty) {
      return "required";
    } else if (value.length < 6) {
      return "Should be at least 6 characters";
    } else if (value.length > 15) {
      return "should not be more than 15 characters";
    } else {
      return null;
    }
  }

  validate() {
    key.currentState.validate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Partner Preferences'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Form(
          child: Column(
            children: [
              TF(
                hinttext: 'Age',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _age,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Marital status',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _maritalstatus,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Religion',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _religion,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Education',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _education,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'State',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _state,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        // if (key.currentState.validate() == false) {
                        //   validate();
                        // } else {
                          map = {
                          // 'id': 'null',
                          'user_id': 'null',
                          'age_': _age.text,
                          'marital_status': _maritalstatus.text,
                          'religion_': _religion.text,
                          'education_status': _education.text,
                          'state_of_liveing': _state.text,
                          'delete_':false
                        };
                        partnerprefer(map);
                        print('tttttttttttttttttttttt');
                        print(map);
                        // }
                      },
                      text: "Submit",
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void partnerprefer(map) async {
    print(map);
    print('userprofile map printinggggg');
    // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    // header.customHeaders['Authorization'] =
    //     sharedPreferences.getString('token');
    // print(header.customHeaders);
    // http.Response response = await http.post(
    //     Uri.parse('http://localhost:3000/about_me'),
    //     headers: header.customHeaders,
    //     body: jsonEncode(map));
    // print('sending data to the server');
    // print(response.body.toString());
    var response =  await networkHandler.post('/add_partner_preference', map);
    print(response.toString());

    print(response["status"]);
    var result = response["status"];

    if (result == 200) {
      showAlertDialog(context);
    } else if (result == 400) {
      setState(() {
        final snackBar = SnackBar(content: Text('Ooops! something went wrong'));
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
      });
    }
  }
}

// Alert Dialog for sign up

showAlertDialog(BuildContext context) {
  // Create button
  Widget okButton = ElevatedButton(
    child: Text("OK"),
    onPressed: () {
      Navigator.of(context).pop();
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return PartnerPref();
      }));
    },
  );

  // Create AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("saved successfully"),
    content: Text("congratz your data saved"),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
