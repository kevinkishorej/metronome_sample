import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trade/Screen/home_screen.dart';
import 'package:trade/Screen/signup_screen.dart';
import 'package:trade/Utils/appsettings.dart';
// import 'package:trade/utils/utils.dart';
import 'package:provider/provider.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:trade/Components/button.dart';
import 'package:http/http.dart' as http;

class Loginscreen extends StatefulWidget {
  //
  static const ROUTE_ID = "login_screen";
  @override
  _LoginscreenState createState() => _LoginscreenState();
}

class _LoginscreenState extends State<Loginscreen> {
  TextEditingController _emailcontroller;
  TextEditingController _passwordcontroller;
  Map<String, dynamic> map = {};
  @override
  void initState() {
    super.initState();
    _emailcontroller = TextEditingController();
    _passwordcontroller = TextEditingController();
  }

  GlobalKey<FormState> key = GlobalKey<FormState>();
  String validatepass(value) {
    if (value.isEmpty) {
      return "required";
    } else if (value.length < 6) {
      return "Should be at least 6 characters";
    } else if (value.length > 15) {
      return "should not be more than 15 characters";
    } else {
      return null;
    }
  }

  validate() {
    key.currentState.validate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: context.watch<Appsettings>().appcolor,
        title: Text("Login"),
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        child: Form(
          key: key,
          child: Column(
            children: [
              // TextField(
              //   controller: _emailcontroller,
              // ),
              // Utils.getTF(_emailcontroller),
              // Utils.getTF(_passwordcontroller),
              // TextField(
              //   controller: _emailcontroller,
              // ),
              TF(
                controller: _emailcontroller,
                hinttext: 'E-mail',
                onChanged: (value) => validate(),

                // helptext: 'E-mail',
                prefixicon: Icons.email,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  } else if (value.length < 6) {
                    return "Should be at least 6 characters";
                  } else if (value.length > 15) {
                    return "should not be more than 15 characters";
                  } else {
                    return null;
                  }
                },
              ),

              TF(
                controller: _passwordcontroller,
                hinttext: 'Password',
                onChanged: (value) => validate(),
                // helptext: 'Password',
                ispassword: true,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  } else if (value.length < 6) {
                    return "Should be at least 6 characters";
                  } else if (value.length > 15) {
                    return "should not be more than 15 characters";
                  } else {
                    return null;
                  }
                },
                prefixicon: Icons.lock_open,
              ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        if (key.currentState.validate() == false) {
                          validate();
                        } else {}

                        map = {
                          "email": _emailcontroller.text,
                          "password": _passwordcontroller.text,
                        };
                        _verifyuser(map);
                        print('eeeeeeeeeeeeeeeeeee');
                        print(map);
                        // Navigator.push(context,
                        //     MaterialPageRoute(builder: (context) {
                        //   return Homescreen();
                        // }));
                        // Utils.savedloggedin(true);
                      },
                      text: "Login",
                      color: context.watch<Appsettings>().appcolor,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        // validate();
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) {
                          return SignupScreen();
                        }));
                        // Utils.savedloggedin(true);
                      },
                      text: "signup",
                      // color: context.watch<Appsettings>().appcolor,
                      color: Colors.blueAccent,
                    ),
                  ),
                ],
              ),
              // Linkbtn(
              //   text: "Forgot password ?",
              //   onpress: () {},
              //   color: context.watch<Appsettings>().appcolor,
              // ),
            ],
          ),
        ),
      ),
    );
  }

  void _verifyuser(map) async {
    print(map);
    print('gjdfkhgdjkfhgdfg');
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    http.Response response = await http
        .post(Uri.parse('http://localhost:3000/user_login'), body: map);

    print('request sended to the server');
    print(response.body.toString());
    print(jsonDecode(response.body.toString())["status"]);
    var result = jsonDecode(response.body.toString())["status"];
    var token = jsonDecode(response.body.toString())["token"];
    print(token);
    if (result == 200) {
      sharedPreferences.setString('token', token);
      Navigator.of(context).pop();

      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return HomeScreen();
      }));
    } else if (result == 400) {
      final snackBar = SnackBar(content: Text('Ooops! something went wrong'));
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }
}
