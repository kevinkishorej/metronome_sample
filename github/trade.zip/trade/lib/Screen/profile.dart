import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:trade/Components/button.dart';
import 'package:http/http.dart' as http;
import 'package:trade/Screen/services/header.dart';
import 'package:trade/Screen/services/request_confic.dart';

class ProfilePage extends StatefulWidget {
  static const ROUTE_ID = 'Profile_page';
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  TextEditingController _usernamecontroller;
  TextEditingController _maritialstatuscontroller;
  TextEditingController _agecontroller;
  TextEditingController _heightcontroller;
  TextEditingController _weightcontroller;
  TextEditingController _bloodgroupcontroller;
  TextEditingController _religioncontroller;
  TextEditingController _educationcontroller;
  TextEditingController _anualincomecontroller;
  TextEditingController _workingdomaincontroller;
  TextEditingController _statecontroller;
  NetworkHandler networkHandler = NetworkHandler();
  Map<String, dynamic> map = {};
  @override
  void initState() {
    // TODO: implement initState

    super.initState();
    _usernamecontroller = TextEditingController();
    _maritialstatuscontroller = TextEditingController();
    _agecontroller = TextEditingController();
    _heightcontroller = TextEditingController();
    _weightcontroller = TextEditingController();
    _bloodgroupcontroller = TextEditingController();
    _religioncontroller = TextEditingController();
    _educationcontroller = TextEditingController();
    _anualincomecontroller = TextEditingController();
    _workingdomaincontroller = TextEditingController();
    _statecontroller = TextEditingController();
    get_user_details();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    get_user_details();
  }
  
void get_user_details() async {
    var response = await networkHandler.post('/get_about_me', map2);
    response =
        json.decode(response['response'][0]['get_user_about_me_details']);
    print(response);
    setState(() {
      mapResponse = response['data'];
      print('sssssssssssssssssssssssssssssssss');
      print(mapResponse);
        _maritialstatuscontroller.text = mapResponse['marital_status'];
         _heightcontroller.text = mapResponse['user_hight'];
       _usernamecontroller.text = mapResponse['full_name'];
       _weightcontroller.text =  mapResponse['user_weight'];
        _religioncontroller.text =  mapResponse['religion_'];
        _bloodgroupcontroller.text = mapResponse['blood_group'];
      _agecontroller.text =  mapResponse['_age'].toString();
      print('sssssssssssssssssssssssssssssssss');
    });
  }
    Map<String, String> map2 = {'user_id': 'null'};
  Map<String, dynamic> mapResponse;
  GlobalKey<FormState> key = GlobalKey<FormState>();
  String validatepass(value) {
    if (value.isEmpty) {
      return "required";
    } else if (value.length < 6) {
      return "Should be at least 6 characters";
    } else if (value.length > 15) {
      return "should not be more than 15 characters";
    } else {
      return null;
    }
  }

  validate() {
    key.currentState.validate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile Page'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Form(
          child: Column(
            children: [
              TF(
                hinttext: 'User Name',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _usernamecontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'marital status',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _maritialstatuscontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Age',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _agecontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  //  else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Height',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _heightcontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  //  else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Weight',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _weightcontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  //  else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Blood Group',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _bloodgroupcontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  //  else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Religion',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _religioncontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  //  else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              // TF(
              //   hinttext: 'Education',
              //   // onChanged: (value) => validate(),
              //   prefixicon: Icons.person,
              //   controller: _educationcontroller,
              //   validator: (value) {
              //     if (value.isEmpty) {
              //       return "required";
              //     }
              //     //  else if (value.length < 6) {
              //     //   return "Should be at least 6 characters";
              //     // }
              //   },
              // ),
              // TF(
              //   hinttext: 'Anual Income',
              //   // onChanged: (value) => validate(),
              //   prefixicon: Icons.person,
              //   controller: _anualincomecontroller,
              //   validator: (value) {
              //     if (value.isEmpty) {
              //       return "required";
              //     }
              //     //  else if (value.length < 6) {
              //     //   return "Should be at least 6 characters";
              //     // }
              //   },
              // ),
              // TF(
              //   hinttext: 'Working Domain',
              //   // onChanged: (value) => validate(),
              //   prefixicon: Icons.person,
              //   controller: _workingdomaincontroller,
              //   validator: (value) {
              //     if (value.isEmpty) {
              //       return "required";
              //     }
              //     //  else if (value.length < 6) {
              //     //   return "Should be at least 6 characters";
              //     // }
              //   },
              // ),
              // TF(
              //   hinttext: 'State',
              //   // onChanged: (value) => validate(),
              //   prefixicon: Icons.person,
              //   controller: _statecontroller,
              //   validator: (value) {
              //     if (value.isEmpty) {
              //       return "required";
              //     }
              //     //  else if (value.length < 6) {
              //     //   return "Should be at least 6 characters";
              //     // }
              //   },
              // ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        // if (key.currentState.validate() == false) {
                        //   validate();
                        // } else {
                        map = {
                          'id': 'null',
                          'user_id': 'null',
                          'full_name': _usernamecontroller.text,
                          'marital_status': _maritialstatuscontroller.text,
                          'age': _agecontroller.text,
                          'user_hight': _heightcontroller.text,
                          'user_weight': _weightcontroller.text,
                          'blood_group': _bloodgroupcontroller.text,
                          'religion_': _religioncontroller.text,
                          // 'eduction_': _educationcontroller.text,
                          // 'annual_icme': _anualincomecontroller.text,
                          // 'working_domain': _workingdomaincontroller.text,
                          // 'state_': _statecontroller.text,
                        };
                        _userprofile(map);
                        print('tttttttttttttttttttttt');
                        print(map);
                        // }
                      },
                      text: "Submit",
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  void _userprofile(map) async {
  print(map);
  print('userprofile map printinggggg');
   SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  header.customHeaders['Authorization'] = sharedPreferences.getString('token');
    print(header.customHeaders);
  http.Response response =
      await http.post(Uri.parse('http://localhost:3000/about_me'),headers: header.customHeaders , body: jsonEncode(map) );
  print('sending data to the server');
  print(response.body.toString());
}
 void _getprofile(map) async {
    print('userprofile map printinggggg');
   SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  header.customHeaders['Authorization'] = sharedPreferences.getString('token');
    print(header.customHeaders);
  http.Response response =
      await http.post(Uri.parse('http://localhost:3000/get_about_me'),headers: header.customHeaders , body: jsonEncode({'user_id':'null'}) );
  print('sending data to the server');
  print(response.body.toString());
 }
}

// user profile function


