class Chatmodel{
  
  int chat_person_list_id;
  int user_id;
  int contact_id;
  String person_name;
  bool delete_flag;
  String user_email;

  Chatmodel(this.chat_person_list_id,this.user_id,this.contact_id,this.person_name,this.delete_flag,this.user_email);

  Chatmodel.formate(Map<String, dynamic> json){
   chat_person_list_id = json['chat_person_list_id'];
   user_id = json['user_id'];
   contact_id = json['contact_id'];
   person_name = json['person_name'];
   delete_flag = json['delete_flag'];
   user_email = json['user_email'];
  }
}
class Chat{
  

  int sender_id;
  int reciver_id;
  String message_;
  String img_message;
  bool   seen_;
  bool   delete_flag;
  String time_date;

  Chat(this.sender_id,this.reciver_id,this.message_,this.img_message,this.seen_,this.delete_flag,this.time_date);

  Chat.formate(Map<String, dynamic> json){
   sender_id = json['sender_id'];
   reciver_id = json['reciver_id'];
   message_ = json['message_'];
   img_message = json['img_message'];
   seen_ = json['seen_'];
   delete_flag = json['delete_flag'];
   time_date = json['time_date'];
  }
}