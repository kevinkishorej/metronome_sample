import 'dart:convert';
import 'dart:html';

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:trade/Screen/family_details.dart';
import 'package:trade/Screen/home_screen.dart';
import 'package:trade/Screen/partner_pref.dart';
import 'package:trade/Screen/profile.dart';
import 'package:trade/Screen/services/request_confic.dart';
import 'package:image_picker/image_picker.dart';
import 'package:io/io.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:http/http.dart' as http;

class main_profile extends StatefulWidget {
  main_profile({Key key}) : super(key: key);

  @override
  main_profileState createState() => main_profileState();
}

class main_profileState extends State<main_profile> {
  final picker = ImagePicker();
  bool content = false;
  bool content1 = false;
  bool validatore = true;
  final errortext = "values is not entred";
  PickedFile _imagefiel;
  TextEditingController _usernamecontroler = TextEditingController();
 
  List profileimgurl;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    get_user_details();
    _usernamecontroler.text = 'I am making this profile for my relative. He completed his masters degree and is now working as a software professional. He belongs to a middle class, joint family with moderate values, currently settled in Chennai.';
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
     get_user_details();
  }

  uploadImage(data) {
    InputElement uploadInput = FileUploadInputElement()..accept = 'image/*';
    uploadInput.click();
    uploadInput.onChange.listen((event) {
      final file = uploadInput.files.first;
      final reader = FileReader();
      reader.readAsArrayBuffer(file);
      reader.onLoadEnd.listen((event) async {
        setState(() {
          profileimgurl = reader.result;
          // companycer = true;
        });
        var imagebase64 = base64.encode(profileimgurl);
       
          mapimage = {
          'ID': mapResponse['_id'],
          'user': mapResponse['full_name'].toString(),
          'base64':imagebase64
        };
        
          
        print(mapimage);
         var res =  await networkHandler.post('/add_image', mapimage);
         print(res['response']);
         add_profile_img(res['response'],data);
      });
    });
  }


  add_profile_img(imge_url,data)async{
    if(data == 'cover_photo'){
          mapResponse = {
          'user_id': mapResponse['_id'],
          'user_img':'null',
          'cover_photo':imge_url,
          
        };
    }if(data == 'profile_pic'){
          mapResponse = {
          'user_id': mapResponse['_id'],
          'user_img':imge_url,
          'cover_photo':'null',
          
        };
    }
    print(mapResponse);
  var res =  await networkHandler.post('/profile_imag_update', mapResponse);
  print(res);
  if(res['status']==200){
     get_user_details();
  }
  }



  void get_user_details() async {
    var response = await networkHandler.post('/get_about_me', map);
    response =
        json.decode(response['response'][0]['get_user_about_me_details']);
    print(response);
    setState(() {
      mapResponse = response['data'];
      print('sssssssssssssssssssssssssssssssss');
      print(mapResponse);

      print('sssssssssssssssssssssssssssssssss');
    });
  }



  NetworkHandler networkHandler = NetworkHandler();
  Map<String, String> map = {'user_id': 'null'};
  Map<String, dynamic> mapimage ;
  Map<String, dynamic> mapResponse;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue.shade400,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return HomeScreen();
            }));
          },
        ),
        title: Center(child: Text('Your Profile')),
      ),
      body: ListView(
        children: [
           head(),
          Divider(
            thickness: 0.8,
          ),
          SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Card(
              elevation: 4,
              color: Colors.grey[100],
              child: Column(
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Row(
                          children: [
                            Icon(Icons.paste_outlined, color: Colors.blue),
                            SizedBox(width: 10),
                            Text(
                              'In My Own words',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 24,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      IconButton(
                          icon: content == false
                              ? Icon(Icons.edit)
                              : Icon(Icons.cancel),
                          splashColor: Colors.white,
                          onPressed: () {
                            setState(() {
                              content = !content;
                            });
                          }),
                    ],
                  ),
                  Container(
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: content == false
                          ? Text(
                              'I am making this profile for my relative. He completed his masters degree and is now working as a software professional. He belongs to a middle class, joint family with moderate values, currently settled in Chennai.',
                              style: TextStyle(
                                fontSize: 19,
                              ),
                            )
                          : Column(
                              children: [
                                usernameField('My wordes'),
                              ],
                            ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Divider(
            thickness: 0.8,
          ),
          SizedBox(height: 4),
           aboutme(),
          Divider(
            thickness: 0.8,
          ),
           SizedBox(height: 4),
           family(),
           Divider(
            thickness: 0.8,
          ),
           SizedBox(height: 4),
           partner(),
        ],
      ),
    );
  }

  Widget head() {
    return Container(
      height: 560,
      width: double.infinity,
      child: mapResponse == null
          ? Center(
              child: CircularProgressIndicator(
                backgroundColor: Colors.black,
              ),
            )
          : Column(
              children: [
                Stack(children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      child: Container(
                        color: mapResponse['cover_photo'] == null ? Colors.grey[200]:null,
                        child: Column(children: <Widget>[
                          InkWell(
                            onTap: () {
                              print('Card tapped.');
                            },
                            child: 
                            SizedBox(
                              width: double.infinity,
                              height: 290,
                              child: Stack(
                                                              children: [ mapResponse['cover_photo'] != null ?Ink.image(image:
                                 NetworkImage('http://localhost:3000/${mapResponse['cover_photo']}'),
                                 fit: BoxFit.fill,):Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    
                                    Center(
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons.add_a_photo,
                                            size: 30,
                                          ),
                                          Text(
                                      ' Add a famil photo',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 30,
                                      ),
                                    ),
                                        ],
                                      ),
                                    ),
                                    
                                  ],
                                ),
                                  Positioned(
                              bottom: 5.0,
                              right: 20.0,
                              child: InkWell(
                                  onTap: () {
                                    // await checkuser();
                                    setState(() {
                                      uploadImage('cover_photo');
                                      print('edit group photo');
                                    });
                                  },
                                  
                                
                                    child: Row(
                                      children: [
                                        Container(
                                              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white,   border: Border.all(
                                                width: 1.8,
                                                color: Colors.white, 
                                                )),
                                            child: IconButton(icon: Icon(
                                                Icons.add_a_photo,
                                                size: 28,
                                                color: Colors.black,
                                                ), onPressed: (){
                                                  uploadImage('cover_photo');
                                                }),
                                                // FlatButton.icon(onPressed: (){}, icon:  Icon(
                                                //   Icons.add_a_photo,
                                                //   size: 28,
                                                //   color: Colors.black,
                                                  
                                                //   ),),
                                                
                                              //  IconButton(icon: Icon(
                                              //   Icons.delete,
                                              //   size: 28,
                                              //   color: Colors.black,
                                              //   ), onPressed: (){}) 
                                               
                                               
                                              
                                          
                                        ),
                                        SizedBox(width:10),
                                         Container(
                                              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white,   border: Border.all(
                                                width: 2,
                                                color: Colors.white, 
                                                )),
                                            child: 
                                                IconButton(icon: Icon(
                                                Icons.delete,
                                                size: 28,
                                                color: Colors.black,
                                                ), onPressed: (){

                                                  setState(() async{
                                                              mapResponse = {
                                                              'user_id': mapResponse['_id'],
                                                              'user_img':'null',
                                                              'cover_photo':'null',
                                                              
                                                            };
                                                        
                                                      var res =  await networkHandler.post('/profile_imag_update', mapResponse);
                                                      print(res);
                                                      if(res['status']==200){
                                                        get_user_details();
                                                      }
                                                  });
                                                }) 
                                                // FlatButton.icon(onPressed: (){}, icon:  Icon(
                                                //   Icons.add_a_photo,
                                                //   size: 28,
                                                //   color: Colors.black,
                                                  
                                                //   ),),
                                                
                                             
                                               
                                               
                                              
                                          
                                        ),
                                      ],
                                    ),
                                  )),

                               ]
                              ),
                            ),
                          ),
                        
                        ]),
                      ),
                    ),
                  ),
                ]),
                Center(
                  child: Stack(
                    children: [
                      
                      CircleAvatar(
                        radius: 80.0,
                        backgroundColor: Colors.grey[200],
                        
                        backgroundImage: mapResponse['profile_img']==null? mapResponse['gender']== null ?AssetImage('images/Men-Profile-Image-715x657.png'): mapResponse['gender'] == 'male'
                            ? AssetImage('images/Men-Profile-Image-715x657.png')
                            : AssetImage('images/images.jpeg'):NetworkImage('http://localhost:3000/'+mapResponse['profile_img']),
                      ),
                      Positioned(
                          bottom: 4,
                          right: 4,
                          
                          child: Container(
                            
                            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white,   border: Border.all(
                             width: 2,
                             color: Colors.white, 
                            )),
                            child: InkWell(
                                onTap: () {
                                  // await checkuser();
                                  showModalBottomSheet(
                                      context: context,
                                      builder: ((builder) => imagebutton()));
                                },
                                child: Icon(
                                  Icons.add_a_photo,
                                  size: 25,
                                  color: Colors.black,
                                )),
                          )),
                      SizedBox(height: 5),
                    ],
                  ),
                ),
                
                Center(
                    child: Column(
                  children: [
                    SizedBox(height: 4),
                    Text(
                      mapResponse['user_name'].toString(),
                  
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 25,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'good to be fit in all situation',
                      style: TextStyle(
                        fontSize: 15,
                      ),
                    ),
                  ],
                ))
              ],
            ),
    );
  }

  Widget imagebutton() {
    return Container(
      height: 150,
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 10),
          Text(
            'Choose to select photos',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 25),
          ),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              FlatButton.icon(
                  onPressed: () {},
                  icon: Icon(Icons.camera_alt),
                  label: Text('Camara')),
              SizedBox(width: 10),
              FlatButton.icon(
                  onPressed: () {
                    uploadImage('profile_pic');
                    // takeimage(ImageSource.gallery);
                  },
                  icon: Icon(Icons.image),
                  label: Text('Galary')),
            ],
          )
        ],
      ),
    );
  }

  Widget usernameField(String lable) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 50.0),
      child: Column(children: [
        TextFormField(
          controller: _usernamecontroler,
          validator: (value) {
            if (value.isEmpty) return "username is required";
            return null;
          },
          decoration: InputDecoration(
              errorText: validatore ? null : errortext,
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2))),
        )
      ]),
    );
  }

  Widget aboutme() {
    return Container(
      child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Card(
            elevation: 4,
            color: Colors.grey[100],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Row(
                        children: [
                          Icon(Icons.accessibility, color: Colors.blue),
                          SizedBox(width: 10),
                          Text(
                            'About me ',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 25),
                          ),
                          SizedBox(width: 20),
                          IconButton(
                          icon: 
                               Icon(Icons.edit),
                              
                          splashColor: Colors.white,
                          onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return ProfilePage();
                          }));
                          }),
                        ],
                      ),
                    )
                  ],
                ),
              
                Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 20),
                  child: mapResponse != null
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Get better responses by verifying your name and age",
                              style: TextStyle(
                                fontWeight: FontWeight.w100,
                                fontSize: 20,
                              ),
                            ),
                            SizedBox(height: 10),
                            Divider(thickness: 1),
                            SizedBox(height: 3),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 15, horizontal: 20),
                              child:mapResponse['about_me_id'] == null? Center(
                                child: Text(
                                "Data is not availabe",
                                style: TextStyle(
                                  fontWeight: FontWeight.w100,
                                  fontSize: 20,
                                ),
                               ),
                              ):Column(
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Age :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 100),
                                      Text(
                                        mapResponse['_age'].toString(),
                                         
                                        
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Marital Status :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 20),
                                      Text(
                                        mapResponse['marital_status'],
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Height :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 78),
                                      Text(
                                          mapResponse['user_hight'],
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Weight :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 76),
                                      Text(
                                         mapResponse['user_weight'],
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Blood group :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 35),
                                      Text(
                                          mapResponse['blood_group'],
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Religion :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 68),
                                      Text(
                                        mapResponse['religion_'],
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        )
                      : Center(
                          child: CircularProgressIndicator(
                            backgroundColor: Colors.black,
                          ),
                        ),
                ),
              ],
            ),
          )),
    );
  }


  Widget family() {
    return Container(
      child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Card(
            elevation: 4,
            color: Colors.grey[100],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Row(
                        children: [
                          Icon(Icons.family_restroom, color: Colors.blue),
                          SizedBox(width: 10),
                          Text(
                            'Family Details',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 25),
                          ),
                          SizedBox(width: 20),
                          IconButton(
                          icon: 
                               Icon(Icons.edit),
                              
                          splashColor: Colors.white,
                          onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return FamilyDetails();
                          }));
                          }),
                        ],
                      ),
                    )
                  ],
                ),
                
                Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 20),
                  child: mapResponse != null
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Get better responses by verifying your Family details",
                              style: TextStyle(
                                fontWeight: FontWeight.w100,
                                fontSize: 20,
                              ),
                            ),
                            SizedBox(height: 10),
                            Divider(thickness: 1),
                            SizedBox(height: 3),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 15, horizontal: 20),
                              child:mapResponse['family_id'] == null? Center(
                                child: Text(
                                "Data is not availabe",
                                style: TextStyle(
                                  fontWeight: FontWeight.w100,
                                  fontSize: 20,
                                ),
                               )
                               ): Column(
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Father name :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 30),
                                      Text(
                                        mapResponse['fater_name'].toString(),
                                         
                                        
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Mother Name :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 20),
                                      Text(
                                        mapResponse['mother_name'],
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "No of Brother :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 20),
                                      Text(
                                          mapResponse['number_of_bro'].toString(),
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                
                               
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "No of Sister :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 33),
                                      Text(
                                          mapResponse['number_of_sis'].toString(),
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                 
                                ],
                              ),
                            ),
                          ],
                        )
                      : Center(
                          child: CircularProgressIndicator(
                            backgroundColor: Colors.black,
                          ),
                        ),
                ),
              ],
            ),
          )),
    );
  }

  Widget partner() {
    return Container(
      child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Card(
            elevation: 4,
            color: Colors.grey[100],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Row(
                        children: [
                          Icon(Icons.group, color: Colors.blue),
                          SizedBox(width: 10),
                          Text(
                            'Partner Preference',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 25),
                          ),
                          SizedBox(width: 20),
                          IconButton(
                          icon: 
                               Icon(Icons.edit),
                              
                          splashColor: Colors.white,
                          onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return PartnerPref();
                          }));
                          }),
                        ],
                      ),
                    )
                  ],
                ),
             
                Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 20),
                  child: mapResponse != null
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Get better responses by verifying your Partner Preference",
                              style: TextStyle(
                                fontWeight: FontWeight.w100,
                                fontSize: 20,
                              ),
                            ),
                            SizedBox(height: 5),
                            Divider(thickness: 1),
                            SizedBox(height: 3),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 15, horizontal: 20),
                              child: mapResponse['partner_pre_id'] == null? Center(
                                child: Text(
                                "Data is not availabe",
                                style: TextStyle(
                                  fontWeight: FontWeight.w100,
                                  fontSize: 20,
                                ),
                               )
                               ):Column(
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Age :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 90),
                                      Text(
                                        mapResponse['age_'].toString(),
                                         
                                        
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Marital status :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 10),
                                      Text(
                                        mapResponse['pp_marital_status'],
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Religion :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 52),
                                      Text(
                                          mapResponse['pp_religion_'].toString(),
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                
                               
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "Eduction :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 45),
                                      Text(
                                          mapResponse['education_status'].toString(),
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Icon(Icons.person, color: Colors.blue),
                                      SizedBox(width: 20),
                                      Text(
                                        "liveing in :",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                      SizedBox(width: 45),
                                      Text(
                                          mapResponse['state_of_liveing'].toString(),
                                       
                                        style: TextStyle(
                                          fontWeight: FontWeight.w100,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                 
                                ],
                              ),
                            ),
                          ],
                        )
                      : Center(
                          child: CircularProgressIndicator(
                            backgroundColor: Colors.black,
                          ),
                        ),
                ),
              ],
            ),
          )),
    );
  }
}
