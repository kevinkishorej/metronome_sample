import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:trade/Screen/profile/chatmodel_class.dart';
import 'package:trade/Screen/profile/individual_chart.dart';
import 'package:trade/Screen/services/request_confic.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
class Chat_page extends StatefulWidget {
  Chat_page({Key key, this.data}) : super(key: key);
  final dynamic data;

  @override
  Chat_pageState createState() => Chat_pageState();
}

class Chat_pageState extends State<Chat_page> {
  NetworkHandler networkHandler = NetworkHandler();
  String asdasd = 'sadsadsa';
  TextEditingController _chatcontroler = TextEditingController();
  List<Chat> chat = [ ];
  io.Socket socket;
  void get_message() async{
    
                                
      map2= {
      'user_id':widget.data.user_id,
      'reciver_id': widget.data.contact_id,
      'contact_list_id':0,
      };

      var response = await networkHandler.post('/get_user_message',map2 );
      response = json.decode(response['response'][0]['user_chat_list']);
      response = response['data'];
     
        setState(() {
           for(var i in response){
          print('chat_person_list_id');
                
            Chat chatmodels = Chat(i['sender_id'],i['reciver_id'],i['message_'],
            i['img_message'],i['seen_'],i['delete_flag'],i['time_date']);
            print(i['message_']);
            chat.add(chatmodels);
        }
        });
        print(chat.length);
         print('SDSADASDASDASDASDASDSFDASFSAFASFD');
      
  }
  void connect(){
  print('connect fun');
      
    socket = io.io(networkHandler.baseUrl,<String,dynamic>{"transports":["websocket"],"autoConnect":false});
    socket.connect();
    socket.emit('event',widget.data.user_id);
    socket.on('message', (msg) { print(msg);}); 
    socket.on('event2', (msg) {
       print(msg);
        
       }); 
    socket.onConnect((data){
    print('connecasdsadsdasted');

    });
    
    
    // socket.on('message', (msg) { print(msg);});
    //  print('connect444444444444444444444444444444444444ed');
    // });
    print(socket.connected);
   
  }

  void send_to_socket(data1,data2,data3,data4,data5,data6){
      print('data.user_id');
   
     print('data.user_id');
     socket.emit('message',{    'user_id': data1,
                                'reciver_id': data2,
                                'message_': data3,
                                'img_message' :data4,
                                'seen_':data5 ,
                                'delete_flag':data6}); 
     
     
  }
  

  //  void get_user_chat() async {
  //   var response = await networkHandler.post('/get_contact', map);
  //   response = 
  //       json.decode(response['response'][0]['get_chat_contact']);
  //       print(response['data']);
  //       response   = response['data'];
      
         
  //       for(var i in response){
  //         print('chat_person_list_id');
            
  //       Chatmodel chatmodels = Chatmodel(i['chat_person_list_id'],i['user_id'],
  //       i['contact_id'],i['person_name'],i['delete_flag'],i['user_email']);
  //       print(i['chat_person_list_id']);
  //       chatmodel.add(chatmodels);
  //       }
  //        print(chatmodel);
  //        return chatmodel;
  //   }
  void send_message() async{

    var retun = await networkHandler.post('/add_message',map );
 
  }
    Map<String, dynamic> map ;
    Map<String, dynamic> map2 ;
   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    get_message();
   connect();
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
     get_message();
     connect();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue.shade400,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return Individual_chat();
            }));
          },
        ),
        title: Center(child: Text('Your Chat')),
      ),
      body: Container(
        child: Center(
            child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Card(
            elevation: 4,
            color: Colors.grey[100],
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.horizontal()),
            child: Column(
              children: [
                Container(
                  child: Column(
                    children: [
                      ListTile(
                        leading: Container(
                            child: CircleAvatar(
                          child: Icon(Icons.person),
                        )),
                        title: Text(widget.data.person_name),
                      ),
                      Divider(
                        thickness: 0.9,
                      ),
                    ],
                  ),
                ),
                Card(
                  child: Container(
                    color: Colors.grey,
                    width: double.infinity,
                    height: 600,
                    child: chat.length > 0 ?ListView.builder(
                      itemCount: chat.length,
                      itemBuilder: (context,index){
                        return Column(children:[
                          Text(chat[index].message_),
                        ]);
                      }):Center(child: CircularProgressIndicator()),
                    ),
                  ),
                
                Card(
                    child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Row(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width - 100,
                              child: Card(
                                  child: TextFormField(
                                controller: _chatcontroler,
                                validator: (value) {
                                  if (value.isEmpty)
                                    return "username is required";
                                  return null;
                                },
                                decoration: InputDecoration(
                                    // errorText: validatore ? null : errortext,
                                    focusedBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.black, width: 2))),
                              )),
                            ),
                            CircleAvatar(
                              child: 
                              InkWell(
                                onTap: (){
                                  setState(() {
                                   
                                   
                                   map = {
                                    'user_id': widget.data.user_id,
                                    'reciver_id': widget.data.contact_id,
                                    'message_':_chatcontroler.text,
                                    'img_message' :'null',
                                    'seen_':true ,
                                    'delete_flag':false
                                  };

                                  Chat chatmodels2 = Chat(widget.data.user_id,widget.data.contact_id,_chatcontroler.text,'null',true,false,'xxxx');

                                  chat.add(chatmodels2);

                                   send_message();
                                  
                                   send_to_socket(widget.data.user_id,widget.data.contact_id,_chatcontroler.text,'null',true,false);
                                  });

                                },
                               child: Icon(Icons.send), 
                              )
                              
                              ),
                          ],
                        )))
              ],
            ),
          ),
        )),
      ),
    );
  }
}
