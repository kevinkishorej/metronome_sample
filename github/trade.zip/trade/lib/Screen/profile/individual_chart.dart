import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:trade/Screen/home_screen.dart';
import 'package:trade/Screen/profile/chate_page.dart';
import 'package:trade/Screen/profile/chatmodel_class.dart';
import 'package:trade/Screen/services/request_confic.dart';

class Individual_chat extends StatefulWidget {

  @override
  _Individual_chatState createState() => _Individual_chatState();
}

class _Individual_chatState extends State<Individual_chat> {
  bool show = false;

  io.Socket socket;
  NetworkHandler networkHandler = NetworkHandler();
  
List<Chatmodel> chatmodel = [ ];
  void connect(){
    // print('connect fun');
    // socket = io.io(networkHandler.baseUrl,<String,dynamic>{"transports":["websocket"],"autoConnect":false});
    // socket.connect();
    // socket.onConnect((data) => print('connecasdsadsdasted'));
    // print(socket.connected);
    // socket.emit('event',"hellow world"); 
  }
  Map<String, String> map = {'user_id': 'null'};

  Future<List<Chatmodel>> get_user_details() async {
    var response = await networkHandler.post('/get_contact', map);
    response = 
        json.decode(response['response'][0]['get_chat_contact']);
        print(response['data']);
        response   = response['data'];
      
         
        for(var i in response){
          print('chat_person_list_id');
            
        Chatmodel chatmodels = Chatmodel(i['chat_person_list_id'],i['user_id'],
        i['contact_id'],i['person_name'],i['delete_flag'],i['user_email']);
        print(i['chat_person_list_id']);
        chatmodel.add(chatmodels);
        }
         print(chatmodel);
         return chatmodel;
    }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connect();
   
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    connect();
   
  }
   @override

  Widget build(BuildContext context) {
       return Scaffold(
          appBar: AppBar(
        backgroundColor: Colors.blue.shade400,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return HomeScreen();
            }));
          },
        ),
        title: Center(child: Text('Your Chat')),
      ),
  
         body: Container(
           width: double.infinity,
           height: 500,
           
            child:FutureBuilder(future: get_user_details(),
           builder: (BuildContext context, AsyncSnapshot snapshot){
             if(snapshot.data == null){
               return Container(child:Center(child: CircularProgressIndicator(backgroundColor: Colors.blue,)));
             }else{
              SizedBox(height: 8);

               print(snapshot.data[0].person_name);
                print('snapshot.data[0].person_name');
               return  ListView.builder(
              itemCount: snapshot.data.length,
              itemBuilder: (BuildContext context,int index){
              return ListTile(
                  leading: Container(child:CircleAvatar(child: Icon(Icons.person),)),
                  title: Text(snapshot.data[index].person_name),
                  subtitle: Text(snapshot.data[index].user_email),
                  onTap: (){
                    print(snapshot.data[index].toString());
                       Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return Chat_page(
                              data:snapshot.data[index]
                            );
                          }));
                  },
                );
              });
             }
           
           },
          )
         )
       );
  }
}