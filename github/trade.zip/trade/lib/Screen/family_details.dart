import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trade/Components/Text_field.dart';
import 'package:trade/Components/button.dart';
import 'package:http/http.dart' as http;
import 'package:trade/Screen/services/header.dart';
import 'package:trade/Screen/services/request_confic.dart';

class FamilyDetails extends StatefulWidget {
  static const ROUTE_ID = 'Family_details';

  @override
  _FamilyDetailsState createState() => _FamilyDetailsState();
}

class _FamilyDetailsState extends State<FamilyDetails> {
  TextEditingController _fathername;
  TextEditingController _mothername;
  TextEditingController _nofbrothers;
  TextEditingController _nofsisters;
  Map<String, dynamic> map = {};
  NetworkHandler networkHandler = NetworkHandler();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _fathername = TextEditingController();
    _mothername = TextEditingController();
    _nofbrothers = TextEditingController();
    _nofsisters = TextEditingController();
    get_user_details();
  }
  void get_user_details() async {
    var response = await networkHandler.post('/get_about_me', map2);
    response =
        json.decode(response['response'][0]['get_user_about_me_details']);
    print(response);
    setState(() {
      mapResponse = response['data'];
      print('sssssssssssssssssssssssssssssssss');
      print(mapResponse);
      _fathername.text =  mapResponse['fater_name'];
      _mothername.text =  mapResponse['mother_name'];
      _nofbrothers.text =  mapResponse['number_of_bro'].toString();
      _nofsisters.text =  mapResponse['number_of_sis'].toString();
      print('sssssssssssssssssssssssssssssssss');
    });
  }
  Map<String, String> map2 = {'user_id': 'null'};
  Map<String, dynamic> mapResponse;

  GlobalKey<FormState> key = GlobalKey<FormState>();
  String validatepass(value) {
    if (value.isEmpty) {
      return "required";
    } else if (value.length < 6) {
      return "Should be at least 6 characters";
    } else if (value.length > 15) {
      return "should not be more than 15 characters";
    } else {
      return null;
    }
  }

  validate() {
    key.currentState.validate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Family Details'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Form(
          child: Column(
            children: [
              TF(
                hinttext: 'Father Name',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _fathername,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'Mother Name',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _mothername,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'No Of Brothers',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _nofbrothers,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              TF(
                hinttext: 'No Of Sisters',
                // onChanged: (value) => validate(),
                prefixicon: Icons.person,
                controller: _nofsisters,
                validator: (value) {
                  if (value.isEmpty) {
                    return "required";
                  }
                  // else if (value.length < 6) {
                  //   return "Should be at least 6 characters";
                  // }
                },
              ),
              Row(
                children: [
                  Expanded(
                    child: Btn(
                      onpress: () {
                        // if (key.currentState.validate() == false) {
                        //   validate();
                        // } else {
                        Map<String,String> data = {
                          'user_id': 'null',
                          // 'user_id': 'null',
                          'fater_name': _fathername.text,
                          'mother_name': _mothername.text,
                          'number_of_bro': _nofbrothers.text,
                          'number_of_sis': _nofsisters.text,
                          'delete_': 'false',
                        };

                        familydetais(data);
                        print('tttttttttttttttttttttt');
                        print(data);
                        // }
                      },
                      text: "Submit",
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void familydetais(data) async {
    print(map);
    print('userprofile map printinggggg');
    // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    // header.customHeaders['Authorization'] =
    //     sharedPreferences.getString('token');
    // print(header.customHeaders);
    // http.Response response = await http.post(
    //     Uri.parse('http://localhost:3000/add_user_family_details'),
    //     headers: header.customHeaders,
    //     body: jsonEncode(map));
    // print('sending data to the server');
    
      var response =  await networkHandler.post('/add_family', data);
    print(response.toString());

    print(response["status"]);
    var result = response["status"];

    if (result == 200) {
      showAlertDialog(context);
    } else if (result == 400) {
      setState(() {
        final snackBar = SnackBar(content: Text('Ooops! something went wrong'));
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
      });
    }
  }
}

// Alert Dialog for sign up

showAlertDialog(BuildContext context) {
  // Create button
  Widget okButton = ElevatedButton(
    child: Text("OK"),
    onPressed: () {
      Navigator.of(context).pop();
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return FamilyDetails();
      }));
    },
  );

  // Create AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("updated successfully"),
    content: Text("Now you will be redirected to next page"),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
