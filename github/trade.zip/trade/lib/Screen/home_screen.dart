// import 'dart:html';

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trade/Screen/drawer_main.dart';
import 'package:http/http.dart' as http;
import 'package:trade/Screen/profile/individual_chart.dart';

class HomeScreen extends StatelessWidget {
  static const ROUTE_ID = 'home_screen';
  String data = 'User name';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
          actions: <Widget>[
              new IconButton(
                icon: new Icon(Icons.chat),
                onPressed: () {
                     Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return Individual_chat();
                     }));
                },
              ),
            ],
      ),
      drawer: MainDrawer(),
      body: Center(
        child: Text(
          '$data',
        ),
      ),
      floatingActionButton: FloatingActionButton(
        elevation: 10.5,
        child: Icon(Icons.add),
        onPressed: _verifyuser,
      ),
    );
  }

  static Map<String, String> customHeaders = {
    'content-type': 'application/json',
    "Access-Control-Allow-Origin": "*", // Required for CORS support to work
    "Access-Control-Allow-Credentials":
        "true", // Required for cookies, authorization headers with HTTPS
    "Access-Control-Allow-Headers":
        "Origin,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    'Authorization': '',
  };

  void _verifyuser() async {
    print('gjdfkhgdjkfhgdfg');
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    customHeaders['Authorization'] = sharedPreferences.getString('token');
    http.Response response = await http.post(
        Uri.parse('http://localhost:3000/get_user'),
        headers: customHeaders);

    print('request sended to the server');

    data = response.body.toString();
    print(data);
  }
}
