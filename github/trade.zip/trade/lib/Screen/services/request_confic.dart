
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:logger/logger.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trade/Screen/services/header.dart';

class NetworkHandler{

    String  baseUrl = "http://localhost:3000";

//logger..
      var log = Logger();

//getapi..
      Future get(String url)async{
        url = formate(url);
        print(url);
         var response = await http.get(Uri.parse(url));
         if(response.statusCode == 200 ||response.statusCode == 201){
         log.i(response.body);
         log.i('sadasdasdd');
         
         print(response.body);
         return  json.decode(response.body);
         }
        log.d(response.body);
        log.d(response.statusCode);   
         return  json.decode(response.body);
      }


//postapi..
        Future post(String url,Map<String,dynamic> body)async{
        url = formate(url);
        print( header.customHeaders);
          SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
          header.customHeaders['Authorization']  = sharedPreferences.getString('token');
        var response = await http.post(Uri.parse(url),headers: header.customHeaders,body: jsonEncode(body));
        if(json.decode(response.body)== 'Session_time_out JWT is expired'){
              await sharedPreferences.remove('token');
        }
        if(response.statusCode == 200 ||response.statusCode == 201){
         log.i(response.body);
         return  json.decode(response.body);
         }
        log.d(response.body);
        log.d(response.statusCode);
         return  json.decode(response.body);
      }






      // Future picture_take(String url, filepath)async{
      //   url = formate(url);
      //   print(' ');
      //     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      //   var token  = sharedPreferences.getString('token');
      //   var reulte =  await http.MultipartRequest('POST', Uri.parse(url));
      //   this.image= filepath;
      //   Uint8List data = await filepath.readAsBytes();
      //   List<int> list = data.cast();
      //   reulte.files.add(await http.MultipartFile.fromBytes('files', list,filename:' myfile.jpg'));
      //   reulte.headers.addAll({
         
      //       'content-type': 'multipart/form-data',
      //       'Authorization': '${token}',

      //   });
      //   var respons = await reulte.send();
      //     print(' asdasdsadsadadsadfdgdfg');
      // }
      // var image;
      // Future setImage(image){
      //   this.image = image;
      // }


    String formate(String url){
      return baseUrl+url;
    }
}