Map<String, dynamic> appSettings = const {
    'SERVER_URL': 'http://127.0.0.1:3000',
};