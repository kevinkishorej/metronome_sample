// To parse this JSON data, do
//
//     final userData = userDataFromJson(jsonString);

import 'dart:convert';

UserData userDataFromJson(String str) => UserData.fromJson(json.decode(str));

String userDataToJson(UserData data) => json.encode(data.toJson());

class UserData {
  UserData({
    this.userName,
    this.email,
    this.mobile,
    this.password,
    // this.confirmPassword,
  });

  String userName;
  String email;
  String mobile;
  String password;
  // String confirmPassword;

  factory UserData.fromJson(Map<String, dynamic> json) => UserData(
        userName: json["user_name"],
        email: json["email"],
        mobile: json["mobile"],
        password: json["password"],
        // confirmPassword: json["confirm_password"],
      );

  Map<String, dynamic> toJson() => {
        "user_name": userName,
        "email": email,
        "mobile": mobile,
        "password": password,
        // "confirm_password": confirmPassword,
      };
}
