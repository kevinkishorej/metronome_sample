const joi = require('@hapi/joi');

const schema ={
    "/get_user":joi.object({
      
    }),

    "/user_login":joi.object({
        'email' :joi.string().max(100).required(),
        'password' :joi.string().max(100).required(),
    }),

    "/insert":joi.object({
        'user_name' :joi.string().max(100).required(),
        'email' :joi.string().email().required(),
        'mobile' :joi.number().min(1000000000).message('invale mobile number').max(9999999999).message('invale mobile number'),
        'password' :joi.string().max(100).required(),
    }),

    "/delete":joi.object({
        'id' :joi.number().max(100).required(),
    }),

}

module.exports = schema;