const express = require('express');
const { Router } = require('express');
const app = express(Router);
const database = require('../Database/db_query');
const jwt = require('jsonwebtoken')
require('dotenv').config();
const {JWT_validator} = require('../Schema/validatore/_validatore')


///sample api do't use
app.post('/get_user',JWT_validator,async(req,res)=>{
    console.log("askndkjnsada")
    const data = await  database.executeQuery('select select_user($1,$2)',[req.sessionPayload['id'],req.sessionPayload['email_id']] )
    res.status(200).json({
        "response": data
    })
})




//login.....
app.post('/user_login', async (req, res) => {
    try {
        const { email, password } = req.body
        console.log(email, password, 'post api received');
        console.log('Received content successflully');
        var user_data = await database.executeQuery("select user_login($1,$2)", [email, password])
       
        var result = user_data[0].user_login
         user_data = JSON.parse(result);
         var token = jwt.sign(user_data.data,process.env.secret_ket, { expiresIn: '5h'})
        if (result.error != null) {
            res.status(400).json({
                "response": user_data,
                "status": 400,
            })
        } else {
            res.status(200).json({
                "response": user_data,
                "token":token,
                "status": 200,
            })
        }


    } catch (error) {
        console.log(error, 'fsdfgsdjfgsjd')
        res.status(400).json({
            "response": result,
            "status": 400,
        })
    }

});


//create_user_profile....
app.post('/insert', async (req, res) => {
    try {
        console.log(req)
        const { user_name, email, mobile, password } = req.body
        console.log(user_name, email, mobile, password, 'post api received');
        var post_user_data = await database.executeQuery("select matri_user($1,$2,$3,$4)", [user_name,
            email, password, mobile]);
        console.log(post_user_data, "adasd")
        // res.send(post_user_data.rows)
        res.status(200).json({
            "response": post_user_data.rows,
            "status": 200,
        })
    } catch (error) {
        res.status(400).json({
            "response": false,
            "status": 400,
        })
    }

})

///user_name already excist are not......
app.get('/exists/:user_name', async (req, res) => {
    try {
        console.log(req)
       var user_name = req.params.user_name;
       
        var post_user_data = await database.executeQuery("select _id from new_user_log where user_name =($1) ",[user_name]);
        console.log(post_user_data.length,"asdasdasdadadsadsad")
        // res.send(post_user_data.rows)
        if(post_user_data.length  == 1){
            res.status(400).json({
                "response": "user_name already exists",
                "status": 400,
            })
        }else{  
                res.status(200).json({
                "response": "no_user_exists",
                "status": 200,
            })
        }
    } catch (error) {
      
    }

})


//delete_user_profile....
app.post('/delete', async (req, res) => {
    const { id } = req.body;
    console.log(id, "requested body no");
    var delete_user_data = await database.executeQuery("select delete_user($1)", [id]);
    res.send(delete_user_data.rows)
})

//updateing_user_profile....
app.post('/update', async (req, res) => {
    const { id, username, password, gender, age } = req.body;
    console.log(req.body, "update query executed");
    var update_user_data = await database.executeQuery("select update_user($1,$2,$3,$4,$5)", [id, username, password, gender, age]);
    res.send(update_user_data.rows)
})



module.exports = app;



