const express = require('express');
const { Router } = require('express');
const app = express(Router);
const database = require('../Database/db_query');
const jwt = require('jsonwebtoken')
require('dotenv').config();
const {JWT_validator} = require('../Schema/validatore/_validatore')

















//add upload image  details...
app.post('/add_chat_contact',async (req,res)=>{
    console.log(req.body)
    var payload  = req.body;
    
    console.log(payload);
    var get_ = await database.executeQuery("select add_contact_to_chat($1,$2,$3,$4)",
    [req.sessionPayload['id'],payload['contact_id'],payload['person_name'],payload['delete_flag']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
 })


 app.post('/get_contact',async (req,res)=>{
    console.log(req.body)
    var payload  = req.body;
    console.log("askndkaaaaaaaaaaaaaaaaajnsada")
    console.log(payload);
    var get_ = await database.executeQuery("select get_chat_contact($1)",
    [req.sessionPayload['id']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
 })



 app.post('/add_message',async (req,res)=>{
    console.log(req.body)
    var payload  = req.body;
    console.log("askndkaaaaaaaaaaaaaaaaajnsada")
    console.log(payload);
    var get_ = await database.executeQuery("select add_user_message($1,$2,$3,$4,$5,$6)",
    [payload['user_id'],payload['reciver_id'],payload['message_'],payload['img_message'],payload['seen_'],payload['delete_flag']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
 })


 app.post('/get_user_message',async (req,res)=>{
    console.log(req.body)
    var payload  = req.body;
    console.log("askndkaaaaaaaaaaaaaaaaajnsada")
    console.log(payload);
    var get_ = await database.executeQuery("select user_chat_list($1,$2,$3)",
    [payload['user_id'],payload['reciver_id'],payload['contact_list_id']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
 })



 app.post('/share_holder',async (req,res)=>{
    console.log(req.body)
    var payload  = req.body;
    console.log(payload);
    var get_ = await database.executeQuery("select add_user_message($1,$2,$3,$4,$5,$6)",
    
    [payload['user_id'],payload['name'],payload['shares'],payload['Nationality'],payload['img_message'],payload['seen_'],payload['delete_flag']]);
    console.log(get_)
    res.status(200).json({
        "response": get_,
        "status": 200,
    })
 })

module.exports = app;
