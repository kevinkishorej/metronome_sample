
const express = require('express'); //api package 
const app = express(); //assigned to app
const cors = require('cors');
const bodyParser = require('body-parser')
const router_services = require('./Routers/index')
const {Pool} = require('pg')
require('dotenv').config()


//middleware...........@@@@@@
app.use(cors());
// app.use(express.json()); // receving body as json
// app.use(bodyParser.urlencoded({ extended: false }))
// app.use(bodyParser.json({
//     limit: '1gb',
//     parameterLimit: 100000,
//     extended: true 
//   }))

app.use(express.json({limit: '50mb'}));
app.use(express.urlencoded({limit: '50mb'}));
app.use(express.static(__dirname + '/Public/images'));




//chating socketio............@@@@@@
const http = require('http');
const server = http.createServer(app)
const io =  require('socket.io')(server);
var client = {}

io.on('connection', function(socket){
  
  
       
        socket.on('/event',(id)=>{
            console.log(id);
            io.emit('/event2', 'socket connected sent by server') 
            console.log(client);
        })
    socket.on('/message',(message)=>{
        console.log(message);
        // io.emit('event2', 'socket connected sent by server')
        io.emit('/message', message)

        // io.emit('message2', 'message');
        console.log('sdsddddddddddddddddddddddddddddddddd ddddd');
    })
  });


//server_router_like_to_the_services...........@@@@@@
app.use('/',router_services);


//lisining port...........@@@@@@
server.listen(process.env.PORT, (req, res) => {
    console.table('Hi im started in ' + process.env.PORT)
});



