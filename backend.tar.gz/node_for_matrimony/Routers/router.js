const express = require('express');
const { Router } = require('express');
const app = express(Router);
const login = require('../Services/login_');
const user_details = require('../Services/user_details');
const chat = require('../Services/chat');
const socket = require('../Services/socket');
const payments = require('../Services/payments');
const {Schema_validator} = require('../Schema/validatore/_validatore');
const {JWT_validator} = require('../Schema/validatore/_validatore');
const {socket_ } = require('../Services/socket')

app.use('/',payments) ;
// app.use('/socket',socket_,socket) ;
app.use('/',Schema_validator,login);
app.use('/',Schema_validator,JWT_validator,user_details) ;
app.use('/',Schema_validator,JWT_validator,chat) ;
 



module.exports = app;  